<?php
session_start();

// Kiểm tra nếu người dùng chưa đăng nhập hoặc chưa được đánh dấu cần xác thực OTP
if (!isset($_SESSION['otp_required']) || $_SESSION['otp_required'] !== true) {
    header("Location: login.php");
    exit;
}

$error_message = "";
$correct_otp = "5555"; // OTP hardcoded theo yêu cầu

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $entered_otp = trim($_POST['otp'] ?? '');

    if ($entered_otp === $correct_otp) {
        // Xác thực OTP thành công
        
        // Hoàn tất quá trình đăng nhập 
        $_SESSION['is_logged_in'] = true;
        // Xóa cờ yêu cầu OTP
        unset($_SESSION['otp_required']); 
        
        header("Location: dashboard.php");
        exit;
    } else {
        $error_message = "Mã OTP không hợp lệ. Vui lòng thử lại.";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xác thực OTP</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .otp-card {
            background: white;
            padding: 30px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin: 50px auto;
            max-width: 300px;
            text-align: center;
        }
        .otp-card h1 {
            color: #d8202f; 
            margin-bottom: 20px;
            font-size: 1.5em;
        }
       .otp-form input[type="text"] {
            /* Đảm bảo input là block element để dùng margin auto */
            display: block; 
            /* Chiếm 90% chiều rộng của .otp-card (trừ padding) để cân đối */
            width: 90%; 
            /* CĂN GIỮA: Đẩy input ra giữa form */
            margin: 0px auto 20px auto; 
            
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            text-align: center;
            font-size: 1.2em;
            letter-spacing: 5px;
            box-sizing: border-box;
        }
        .otp-form button {
            background-color: #d8202f; /* Màu đỏ MB Bank */
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 1em;
            font-weight: 700;
        }
        .error-message {
            color: #d8202f;
            margin-bottom: 15px;
            font-weight: 600;
        }
    </style>
</head>
<body class="mobile-layout login-body">
    <main class="login-main">
        <div class="otp-card">
            <h1>Xác thực OTP</h1> 
            <p>Vui lòng nhập mã OTP được gửi đến điện thoại của bạn.</p>

            <form action="otp_verification.php" method="POST" class="otp-form">
                <?php if ($error_message): ?>
                    <p class="error-message"><?php echo $error_message; ?></p>
                <?php endif; ?>

                <input type="text" id="otp" name="otp" required maxlength="4" 
                       placeholder="Mã OTP (5555)">

                <button type="submit">Xác nhận</button>
            </form>

            <p style="margin-top: 20px; font-size: 0.9em; color: #888;">Mã OTP là 5555</p>
        </div>
    </main>
</body>
</html>