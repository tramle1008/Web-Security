<?php
// Thông tin kết nối cơ sở dữ liệu
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); // Thay bằng tên người dùng MySQL của bạn nếu khác
define('DB_PASSWORD', '');     // Thay bằng mật khẩu MySQL của bạn nếu khác
define('DB_NAME', 'bank');

// Kết nối đến cơ sở dữ liệu MySQL
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Lỗi kết nối CSDL: " . $conn->connect_error);
}

// Thiết lập mã hóa UTF8 cho kết nối
$conn->set_charset("utf8mb4");
?>