<?php
session_start();

// Chỉ xử lý việc đăng xuất của quản trị viên
unset($_SESSION['is_admin']);

// Chuyển hướng về trang đăng nhập quản trị
header("Location: admin_login.php");

exit;
?>