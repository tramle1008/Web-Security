<?php
session_start();
require_once 'config.php'; // Bao gồm kết nối CSDL

// Kiểm tra đăng nhập
if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$account_number = $_SESSION['account_number'];
$current_balance = "0.00";

// Lấy số dư hiện tại từ CSDL
$sql = "SELECT balance FROM accounts WHERE id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $stmt->bind_result($balance);
        if ($stmt->fetch()) {
            // Định dạng số dư để hiển thị đẹp hơn
            $current_balance = number_format($balance, 0, ',', '.');
        }
    }
    $stmt->close();
}
$conn->close();

$currency = "VND"; // Đơn vị tiền tệ
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MB Dashboard - <?php echo $user_name; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="mobile-layout">
    <header class="dashboard-header">
        <div class="top-bar">
            <h2 class="mb-text-small-logo">MB</h2> 
            <a href="logout.php" class="logout-btn">Đăng xuất</a>
        </div>
    </header>

    <main class="dashboard-main">
        <section class="user-info">
            <h2>Xin chào, <?php echo $user_name; ?></h2>
            <p>Tài khoản: <?php echo $account_number; ?></p>
        </section>

        <section class="balance-card">
            <div class="balance-title">
                <h3>Số dư khả dụng</h3>
            </div>
            <p class="balance-amount"><?php echo $current_balance; ?> <?php echo $currency; ?></p>
            <div class="buttons-row">
                <a href="transfer.php" class="btn-action">Chuyển tiền</a>
                <a href="#deposit" class="btn-action">Nạp tiền</a>
                <a href="#withdraw" class="btn-action">Rút tiền</a>
            </div>
        </section>
        
        <section class="quick-services-grid">
            <a href="transfer.php" class="service-item">💳 Chuyển tiền</a>
            <a href="#bills" class="service-item">🧾 Thanh toán</a>
            <a href="#saving" class="service-item">💰 Tiết kiệm</a>
            <a href="change_password.php" class="service-item">🔑 Đổi mật khẩu</a>
            <a href="logout.php" class="service-item">🚪 Đăng xuất</a>
            <a href="settings.php" class="service-item">⚙️ Cài đặt</a> </section>

        <section class="promotions">
            <h3>Ưu đãi dành cho bạn</h3>
            <div class="promo-card">Giảm 20% khi thanh toán hóa đơn điện nước!</div>
        </section>
        
        <div style="height: 80px;"></div> 
    </main>
    
    <footer class="app-navigation">
        <a href="dashboard.php" class="nav-item active">🏠 Trang chủ</a>
        <a href="#cards" class="nav-item">💳 Thẻ</a>
        <a href="#tools" class="nav-item">🛠️ Tiện ích</a>
        <a href="#mbbank" class="nav-item">🎯 MB Bank</a>
    </footer>
</body>
</html>