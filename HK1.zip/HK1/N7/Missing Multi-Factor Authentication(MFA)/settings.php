<?php
session_start();

// Kiểm tra đăng nhập
if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Xử lý thay đổi cài đặt OTP
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['otp_setting'])) {
    if ($_POST['otp_setting'] === 'enable') {
        $_SESSION['otp_enabled'] = true;
    } else {
        $_SESSION['otp_enabled'] = false;
    }
    // Ngăn chặn form resubmission
    header("Location: settings.php?status=success");
    exit;
}

// Lấy trạng thái hiện tại
$otp_status = $_SESSION['otp_enabled'] ?? false;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cài đặt OTP</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .settings-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin: 20px auto; 
            max-width: 350px; 
            text-align: center;
        }
        
        /* CHỈNH SỬA TẠI ĐÂY: Giảm khoảng cách giữa hai dòng tiêu đề */
        h2.otp-main-title {
            margin-bottom: 0px; /* Loại bỏ margin phía dưới */
            padding-bottom: 0px; 
        }
        .settings-card h2 {
            margin-top: 0;
            color: #333;
        }
        /* Đảm bảo dòng 2 cũng được điều chỉnh nếu cần */
        .settings-card h2:nth-child(2) {
             margin-top: 5px; /* Thêm một chút margin nhỏ phía trên cho dòng 2 */
        }
        /* KẾT THÚC CHỈNH SỬA */

        .status-message {
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
        }
        .status-enabled {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .status-disabled {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .btn-setting {
            padding: 10px 20px;
            margin: 5px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }
        .btn-enable {
            background-color: #28a745;
            color: white;
        }
        .btn-disable {
            background-color: #dc3545;
            color: white;
        }
        .back-link {
            display: block;
            margin-top: 20px;
            color: #007aff;
            text-decoration: none;
            font-weight: 600;
        }
    </style>
</head>
<body class="mobile-layout">
    <header class="dashboard-header">
        <div class="top-bar">
            <a href="dashboard.php" class="logout-btn" style="float: left; text-decoration: none;">← Quay lại</a>
            <h2 class="mb-text-small-logo" style="text-align: center; margin: 0 auto; display: inline-block;">MB</h2>
        </div>
    </header>
    <main class="dashboard-main">
        <div class="settings-card">
            <h2 class="otp-main-title">Cài đặt OTP</h2> <h2>(Xác thực 2 bước)</h2>
            
            <?php if ($otp_status): ?>
                <div class="status-message status-enabled">
                    OTP đang **BẬT**.
                </div>
                <form action="settings.php" method="POST">
                    <input type="hidden" name="otp_setting" value="disable">
                    <button type="submit" class="btn-setting btn-disable">TẮT OTP</button>
                </form>
            <?php else: ?>
                <div class="status-message status-disabled">
                    OTP đang **TẮT**.
                </div>
                <form action="settings.php" method="POST">
                    <input type="hidden" name="otp_setting" value="enable">
                    <button type="submit" class="btn-setting btn-enable">BẬT OTP</button>
                </form>
            <?php endif; ?>
            
            <a href="dashboard.php" class="back-link">Về Trang chủ</a>
        </div>
    </main>
</body>
</html>