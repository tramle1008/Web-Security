<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$sender_account_number = $_SESSION['account_number'];

$info_message = "";
$error_message = "";
$transfer_success = false;
$current_balance = 0;

// Lấy số dư hiện tại của người gửi
$sql_balance = "SELECT balance FROM accounts WHERE id = ?";
if ($stmt_balance = $conn->prepare($sql_balance)) {
    $stmt_balance->bind_param("i", $user_id);
    if ($stmt_balance->execute()) {
        $stmt_balance->bind_result($balance);
        if ($stmt_balance->fetch()) {
            $current_balance = $balance;
        }
    }
    $stmt_balance->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $receiver_account = trim($_POST['receiver_account'] ?? '');
    // Ép kiểu số tiền về float (số thực)
    $amount = (float)($_POST['amount'] ?? 0); 
    
    // =========================================================
    // ⚠️ KIỂM TRA RÀNG BUỘC SỐ DƯ (RẤT QUAN TRỌNG) ⚠️
    // =========================================================
    if ($receiver_account === $sender_account_number) {
        $error_message = "Không thể chuyển tiền cho chính tài khoản của mình.";
    } elseif ($amount <= 0) {
        $error_message = "Số tiền chuyển phải lớn hơn 0.";
    } elseif ($amount > $current_balance) {
        // RÀNG BUỘC SỐ DƯ ĐƯỢC KÍCH HOẠT TẠI ĐÂY
        $error_message = "Số dư không đủ (" . number_format($current_balance, 0, ',', '.') . " VND) để thực hiện giao dịch này.";
    } else {
        // BẮT ĐẦU TRANSACTION (Giao dịch)
        $conn->begin_transaction();
        
        try {
            // 1. Lấy thông tin tài khoản người nhận
            $sql_receiver = "SELECT id FROM accounts WHERE account_number = ?";
            if (!($stmt_receiver = $conn->prepare($sql_receiver))) { throw new Exception("Lỗi truy vấn người nhận."); }
            $stmt_receiver->bind_param("s", $receiver_account);
            $stmt_receiver->execute();
            $stmt_receiver->store_result();
            if ($stmt_receiver->num_rows == 0) { throw new Exception("Không tìm thấy tài khoản người nhận."); }
            $stmt_receiver->bind_result($receiver_id);
            $stmt_receiver->fetch();
            $stmt_receiver->close();

            // 2. TRỪ TIỀN NGƯỜI GỬI (sender)
            $sql_debit = "UPDATE accounts SET balance = balance - ? WHERE id = ?";
            if (!($stmt_debit = $conn->prepare($sql_debit))) { throw new Exception("Lỗi trừ tiền người gửi."); }
            $stmt_debit->bind_param("di", $amount, $user_id);
            if (!$stmt_debit->execute()) { throw new Exception("Lỗi thực thi trừ tiền."); }
            $stmt_debit->close();

            // 3. CỘNG TIỀN NGƯỜI NHẬN (receiver)
            $sql_credit = "UPDATE accounts SET balance = balance + ? WHERE id = ?";
            if (!($stmt_credit = $conn->prepare($sql_credit))) { throw new Exception("Lỗi cộng tiền người nhận."); }
            $stmt_credit->bind_param("di", $amount, $receiver_id);
            if (!$stmt_credit->execute()) { throw new Exception("Lỗi thực thi cộng tiền."); }
            $stmt_credit->close();

            // Giao dịch thành công
            $conn->commit();
            $transfer_success = true;
            $current_balance -= $amount;
            
            $info_message = "Chuyển khoản thành công! Số tiền " . number_format($amount, 0, ',', '.') . " VND đã được chuyển đến tài khoản $receiver_account.";
        
        } catch (Exception $e) {
            $conn->rollback();
            $error_message = "Giao dịch thất bại: " . $e->getMessage();
        }
    }
}
$conn->close();

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chuyển tiền</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="mobile-layout">
    <header class="dashboard-header">
        <div class="top-bar">
            <a href="dashboard.php" class="logout-btn">← Quay lại</a>
            <h2 class="mb-text-small-logo">MB</h2> 
            <div style="width: 50px;"></div> 
        </div>
    </header>

    <main class="dashboard-main">
        <div class="form-container">
            <h2>Chuyển tiền</h2>
            
            <?php if ($transfer_success): ?>
                <p class="success-message"><?php echo $info_message; ?></p>
            <?php elseif ($error_message): ?>
                <p class="error-message"><?php echo $error_message; ?></p>
            <?php endif; ?>

            <p class="info-message">Số dư hiện tại: <?php echo number_format($current_balance, 0, ',', '.'); ?> VND</p>

            <form action="transfer.php" method="POST">
                <label for="receiver_account">Số tài khoản người nhận</label>
                <input type="text" id="receiver_account" name="receiver_account" required 
                       placeholder="Ví dụ: 888812345678">

                <label for="amount">Số tiền chuyển (VND)</label>
                <input type="number" id="amount" name="amount" required min="1000" step="1000"
                       placeholder="Nhập số tiền">

                <label for="description">Nội dung</label>
                <input type="text" id="description" name="description" 
                       placeholder="Nội dung chuyển khoản">

                <button type="submit" class="btn-submit">Xác nhận chuyển tiền</button>
            </form>
        </div>
    </main>
</body>
</html>