<?php
session_start();
require_once 'config.php'; // Bao gồm kết nối CSDL

// Kiểm tra đăng nhập
if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$error_message = "";
$success_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_password = trim($_POST['old_password'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    // 1. Kiểm tra tính hợp lệ cơ bản
    if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
        $error_message = "Vui lòng điền đầy đủ các trường.";
    } elseif ($new_password !== $confirm_password) {
        $error_message = "Mật khẩu mới và Xác nhận mật khẩu mới không khớp.";
    } elseif (strlen($new_password) < 6) {
        $error_message = "Mật khẩu mới phải có ít nhất 6 ký tự.";
    } else {
        // 2. Lấy mật khẩu cũ từ DB
        $sql_select = "SELECT password FROM accounts WHERE id = ?";
        if ($stmt_select = $conn->prepare($sql_select)) {
            $stmt_select->bind_param("i", $user_id);
            if ($stmt_select->execute()) {
                $stmt_select->bind_result($db_password);
                $stmt_select->fetch();
                $stmt_select->close();

                // 3. Kiểm tra mật khẩu cũ (Vì đang dùng mật khẩu KHÔNG mã hóa)
                if ($old_password === $db_password) {
                    
                    // 4. Cập nhật mật khẩu mới vào DB
                    // (Trong thực tế, new_password cần được mã hóa trước khi lưu)
                    $sql_update = "UPDATE accounts SET password = ? WHERE id = ?";
                    if ($stmt_update = $conn->prepare($sql_update)) {
                        $stmt_update->bind_param("si", $new_password, $user_id);
                        if ($stmt_update->execute()) {
                            $success_message = "Đổi mật khẩu thành công! Bạn có thể dùng mật khẩu mới để đăng nhập.";
                        } else {
                            $error_message = "Có lỗi xảy ra trong quá trình cập nhật mật khẩu.";
                        }
                        $stmt_update->close();
                    }
                } else {
                    $error_message = "Mật khẩu cũ không đúng.";
                }
            } else {
                $error_message = "Lỗi truy vấn cơ sở dữ liệu.";
            }
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đổi mật khẩu</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="mobile-layout">
    <header class="dashboard-header">
        <div class="top-bar">
            <a href="dashboard.php" class="logout-btn">← Quay lại</a>
            <h2 class="mb-text-small-logo">MB</h2> 
            <div style="width: 50px;"></div> 
        </div>
    </header>

    <main class="dashboard-main">
        <div class="form-container">
            <h2>Đổi mật khẩu</h2>
            
            <?php if ($success_message): ?>
                <p class="success-message"><?php echo $success_message; ?></p>
            <?php elseif ($error_message): ?>
                <p class="error-message"><?php echo $error_message; ?></p>
            <?php endif; ?>

            <form action="change_password.php" method="POST">
                <label for="old_password">Mật khẩu cũ</label>
                <input type="password" id="old_password" name="old_password" required 
                       placeholder="Nhập mật khẩu hiện tại">

                <label for="new_password">Mật khẩu mới</label>
                <input type="password" id="new_password" name="new_password" required minlength="6"
                       placeholder="Nhập mật khẩu mới (tối thiểu 6 ký tự)">

                <label for="confirm_password">Xác nhận mật khẩu mới</label>
                <input type="password" id="confirm_password" name="confirm_password" required minlength="6"
                       placeholder="Nhập lại mật khẩu mới">

                <button type="submit" class="btn-submit">Thay đổi mật khẩu</button>
            </form>
        </div>
    </main>
</body>
</html>