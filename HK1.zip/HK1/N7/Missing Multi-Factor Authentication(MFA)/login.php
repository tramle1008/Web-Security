<?php
session_start();
// Bao gồm file kết nối CSDL
require_once 'config.php';

$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // Chuẩn bị truy vấn
    $sql = "SELECT id, username, password, full_name, account_number FROM accounts WHERE username = ?";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $param_username);
        $param_username = $username;

        if ($stmt->execute()) {
            $stmt->store_result();
            
            // Kiểm tra xem tên đăng nhập có tồn tại không
            if ($stmt->num_rows == 1) {
                // Lấy kết quả
                $stmt->bind_result($id, $db_username, $hashed_password, $full_name, $account_number);
                if ($stmt->fetch()) {
                    // Vì mật khẩu không mã hóa, kiểm tra trực tiếp
                    if ($password === $hashed_password) {
                        
                        // 1. LƯU THÔNG TIN TẠM THỜI (TÊN, TÀI KHOẢN...)
                        $_SESSION['user_id'] = $id;
                        $_SESSION['username'] = $db_username;
                        $_SESSION['full_name'] = $full_name;
                        $_SESSION['account_number'] = $account_number;
                        
                        // 2. KIỂM TRA TRẠNG THÁI OTP
                        // SỬA LỖI: Kiểm tra trạng thái OTP đã được bật trong settings chưa.
                        // Chúng ta đang giả lập lưu trạng thái này trong Session.
                        $otp_enabled = $_SESSION['otp_enabled'] ?? false;
                        
                        if ($otp_enabled) {
                            // Nếu OTP BẬT
                            $_SESSION['otp_required'] = true;
                            $_SESSION['is_logged_in'] = false; // Ngăn truy cập dashboard trực tiếp
                            header("Location: otp_verification.php");
                            exit;
                        } else {
                            // Nếu OTP TẮT
                            $_SESSION['is_logged_in'] = true;
                            header("Location: dashboard.php");
                            exit;
                        }

                    } else {
                        // Mật khẩu không đúng
                        $error_message = "Mật khẩu không đúng.";
                    }
                }
            } else {
                // Tên đăng nhập không tồn tại
                $error_message = "Tên đăng nhập không tồn tại.";
            }
        } else {
            $error_message = "Có lỗi xảy ra trong quá trình truy vấn.";
        }
        $stmt->close();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập MB Bank (Mô phỏng)</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="mobile-layout login-body">
    <header class="login-header text-logo-header">
        <div class="header-info">
            <h1 class="mb-text-logo">MB</h1>
        </div>
    </header>

    <main class="login-main">
        <div class="login-card no-purple-card"> 
            <h1 class="login-title-white-bg">Đăng nhập</h1> 
            <form action="login.php" method="POST" class="login-form">
                <?php if ($error_message): ?>
                    <p class="error-message"><?php echo $error_message; ?></p>
                <?php endif; ?>

                <label for="username">Tên đăng nhập</label>
                <input type="text" id="username" name="username" required 
                       placeholder="Nhập tên đăng nhập" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">

                <label for="password">Mật khẩu</label>
                <input type="password" id="password" name="password" required 
                       placeholder="Nhập mật khẩu">

                <button type="submit" class="btn-login-submit">Đăng nhập</button>
            </form>

            <div class="login-links">
                <a href="#">QUÊN MẬT KHẨU?</a>
                <a href="#">TẠO TÀI KHOẢN</a>
            </div>
        </div>
        
        <div class="bottom-utilities">
             <div class="utility-item">🖼️ Quét QR</div>
             <div class="utility-item">🔒 Xác thực D-OTP</div>
             <div class="utility-item">☰ Tiện ích</div>
             <div class="utility-item">💬 Chat với eMBee</div>
        </div>
    </main>
</body>
</html>