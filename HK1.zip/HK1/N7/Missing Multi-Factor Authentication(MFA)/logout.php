<?php
session_start();

// Giữ lại trạng thái OTP đã được lưu (giả lập CSDL)
$otp_status = $_SESSION['otp_enabled'] ?? false;

// Xóa tất cả các biến Session liên quan đến trạng thái đăng nhập hiện tại
unset($_SESSION['is_logged_in']);
unset($_SESSION['user_id']);
unset($_SESSION['username']);
unset($_SESSION['full_name']);
unset($_SESSION['account_number']);
unset($_SESSION['otp_required']); 

// Phục hồi lại trạng thái OTP
$_SESSION['otp_enabled'] = $otp_status;

// Chuyển hướng về trang đăng nhập
header("Location: login.php");
exit;
?>