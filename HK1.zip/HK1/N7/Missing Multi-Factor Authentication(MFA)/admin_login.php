<?php
session_start();
// Mật khẩu quản trị cứng
$admin_password = "123456"; 
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $entered_password = trim($_POST['password'] ?? '');
    
    if ($entered_password === $admin_password) {
        $_SESSION['is_admin'] = true;
        header("Location: list_users.php");
        exit;
    } else {
        $error_message = "Mật khẩu quản trị không đúng.";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập quản trị</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .admin-login-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .admin-login-container h2 {
            font-size: 1.5em;
            margin-bottom: 20px;
        }
        .admin-login-container input {
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .admin-login-container button {
            padding: 10px 15px;
            background-color: #0000a0;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="admin-login-container">
        <h2>Đăng nhập quản trị</h2>
        <?php if ($error_message): ?>
            <p style="color: red;"><?php echo $error_message; ?></p>
        <?php endif; ?>
        <form action="admin_login.php" method="POST">
            <input type="password" name="password" placeholder="Mật khẩu admin" required>
            <button type="submit">Vào trang admin</button>
        </form>
        
        </div>
</body>
</html>