<?php
session_start();

// Kiểm tra xem người dùng đã đăng nhập chưa
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
	<div class="login-container">
    <h2>Chào mừng, <?php echo $_SESSION['username']; ?>!</h2>
    <p>Đây là trang chính của bạn.</p>
    <a href="logout.php">Đăng xuất</a>
	</div>
</body>
</html>
