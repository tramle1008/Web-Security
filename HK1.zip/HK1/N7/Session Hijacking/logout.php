<?php
session_start();

// Xóa toàn bộ session
$_SESSION = array();

// Nếu muốn xóa luôn cookie PHPSESSID trên trình duyệt
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Hủy session
session_destroy();

// Quay lại trang login
header("Location: login.php");
exit;
