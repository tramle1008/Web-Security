<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bank_style.css">
</head>
<body>
    <?php
        session_start();

        // 1. LOGIC RESET SESSION (Đã thêm lại theo yêu cầu)
        if (isset($_GET['reset'])) { 
            session_destroy(); 
            header("Location: bank2.php"); 
            exit; 
        }

        // Khởi tạo tiền và user
        if (!isset($_SESSION['money2'])) $_SESSION['money2']=2000;
        if (!isset($_SESSION['user2'])) $_SESSION['user2']="Bob";

        // 2. TẠO TOKEN YẾU (md5 username)
        $user_id = $_SESSION['user2'];
        if (!isset($_SESSION['token2'])) {
            $_SESSION['token2'] = md5($user_id);
        }
        $token = $_SESSION['token2'];

        $message = "Sẵn sàng nhận lệnh chuyển khoản.";

        // 3. LOGIC XỬ LÝ GIAO DỊCH (Sử dụng GET)
        // Dùng $_GET để bắt tham số từ URL
        if (isset($_GET['token'])) {
            if ($_GET['token'] === $token) {
                if ($_SESSION['money2'] >= 100) {
                    $_SESSION['money2'] -= 100;
                    $message = " Giao dịch thành công! Đã chuyển 100. (Lỗ Hổng: GET + Token yếu)";
                } else {
                    $message = " Không đủ số dư.";
                }
            } else {
                $message = " Lỗi bảo mật: Token không hợp lệ!";
            }
        }
    ?>
    <div class="container">
        <h2> Bank 2 (LỖ HỔNG: Token Dự Đoán Được + GET)</h2>
        <div class="info-box">
            Người dùng: <strong><?php echo htmlspecialchars($_SESSION['user2']);?></strong> | Số dư: <span class="money">$<?php echo $_SESSION['money2'];?></span>
        </div>
        <p style="color:red;"><?php echo $message;?></p>

        <form method="get" style="display:inline-block;">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token);?>">
            <button type="submit"> Chuyển 100 Hợp Lệ</button>
        </form>
        
        <hr>
        <a href="bank3.php" class="nav-link"> Sang Bank 3</a>
        <a href="?reset=1" class="reset-link"> Reset</a>
    </div>
</body>
</html>