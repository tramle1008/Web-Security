<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bank_style.css">
</head>
<body>
   <?php
    session_start();
    if (!isset($_SESSION['money3'])) $_SESSION['money3']=2000;
    if (!isset($_SESSION['user3'])) $_SESSION['user3']="Charlie";

    // TOKEN MẠNH: Ngẫu nhiên, liên kết với session
    if (!isset($_SESSION['token3'])) {
        $_SESSION['token3']=bin2hex(random_bytes(32));
    }
    $token=$_SESSION['token3'];

    $message = "Sẵn sàng nhận lệnh chuyển khoản.";

    if ($_SERVER['REQUEST_METHOD']==='POST') {
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        // Giả định: Domain ngân hàng là http://localhost/csrf_demo/ (Bạn cần chỉnh lại cho phù hợp)
        $domain_hop_le = 'http://localhost/csrf_demo'; 
        $is_same_site = strpos($referer, $domain_hop_le) === 0;

        if ($is_same_site) { // Mô phỏng SameSite=Lax, chặn POST request từ cross-site
            if (isset($_POST['token']) && $_POST['token']==$token) {
                if ($_SESSION['money3'] >= 100) {
                    $_SESSION['money3']-=100;
                    $message = " Giao dịch thành công! (Bảo vệ Tốt)";
                } else {
                    $message = " Không đủ số dư.";
                }
            } else {
                $message = " Lỗi bảo mật: Token không hợp lệ hoặc bị thiếu! (Đã chặn CSRF)";
            }
        } else {
            $message = " **Đã chặn!** Request không đến từ domain hợp lệ (SameSite/Referer check).";
        }
    }

    if (isset($_GET['reset'])) { session_destroy(); header("Location: bank3.php"); exit; }
    ?>
    <link rel="stylesheet" href="bank_style.css">
    <div class="container">
        <h2> Bank 3 (BẢO VỆ TỐT: POST + Token Mạnh + SameSite)</h2>
        <div class="info-box">
            Người dùng: **<?php echo htmlspecialchars($_SESSION['user3']);?>** | Số dư: <span class="money">$<?php echo $_SESSION['money3'];?></span>
        </div>
        <p style="color:green; font-weight: bold;"><?php echo $message;?></p>

        <form method="post" style="display:inline-block;">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token);?>">
            <button type="submit"> Chuyển 100 Hợp Lệ</button>
        </form>
        
        <hr>
        <a href="bank1.php" class="nav-link"> Sang Bank 1</a>
        <a href="?reset=1" class="reset-link"> Reset</a>
</div>

</body>
</html>