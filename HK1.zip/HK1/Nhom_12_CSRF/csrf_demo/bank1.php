<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bank_style.css">
</head>
<body>
   <?php
        session_start();
        // Khởi tạo Session
        if (!isset($_SESSION['money1'])) $_SESSION['money1']=2000;
        if (!isset($_SESSION['user1'])) $_SESSION['user1']="Alice";

        // Xử lý giao dịch GET - LỖ HỔNG CSRF
        if (isset($_GET['transfer'])) {
            if ($_SESSION['money1'] >= 100) {
                $_SESSION['money1']-=100;
                $message = " Giao dịch thành công! Đã chuyển 100. (LỖ HỔNG: Dùng GET)";
            } else {
                $message = " Không đủ số dư.";
            }
        } else {
            $message = "Sẵn sàng nhận lệnh chuyển khoản.";
        }

        if (isset($_GET['reset'])) { session_destroy(); header("Location: bank1.php"); exit; }
    ?>
        <link rel="stylesheet" href="bank_style.css">
        <div class="container">
            <h2> Bank 1 (LỖ HỔNG: GET Request)</h2>
            <div class="info-box">
                Người dùng: **<?php echo htmlspecialchars($_SESSION['user1']);?>** | Số dư: <span class="money">$<?php echo $_SESSION['money1'];?></span>
            </div>
            <p style="color:red;"><?php echo $message;?></p>
            
            <a href="?transfer=1" class="transfer-link"> Chuyển 100 Ngay!</a><br>
            
            <hr>
            <a href="bank2.php" class="nav-link"> Sang Bank 2</a>
            <a href="?reset=1" class="reset-link"> Reset</a>
        </div>
</body>
</html>
