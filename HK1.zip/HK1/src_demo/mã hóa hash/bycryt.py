import bcrypt


plain_password = input("Nhap mat khau muon ma hoa: ")
#  Tap salt ngau nhien va ma hoa
salt = bcrypt.gensalt()
hashed_password = bcrypt.hashpw(plain_password.encode("utf-8"), salt)

#  In ket qua
print("----------------------------")
print(f"Mat khau goc: {plain_password}")
print(f"Salt: {salt.decode()}")
print(f"Mat khau da ma hoa (bcrypt): {hashed_password.decode()}")
