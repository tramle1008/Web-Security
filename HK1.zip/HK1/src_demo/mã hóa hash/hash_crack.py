#!/usr/bin/env python3
import argparse
import hashlib
import sys
import os

def crack(wordlist_path: str, target_hash: str, hash_type: str):
    try:
        with open(wordlist_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                word = line.rstrip("\n\r")
                if not word:
                    continue
                if hash_type == "md5":
                    h = hashlib.md5(word.encode("utf-8")).hexdigest()
                elif hash_type == "sha1":
                    h = hashlib.sha1(word.encode("utf-8")).hexdigest()
                else:
                    print("Loại hash không được hỗ trợ:", hash_type)
                    return False

                if h == target_hash.lower():
                    print(f"Thành công! Giá trị plain-text là: {word}")
                    return True
        print("Thất bại — không tìm thấy mật khẩu trong wordlist.")
        return False
    except FileNotFoundError:
        print("Không tìm thấy file wordlist:", wordlist_path)
        return False
    except Exception as e:
        print("Lỗi khi đọc file:", e)
        return False

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-w", "--wordlist")
    parser.add_argument("-H", "--hash")
    parser.add_argument("-t", "--type")
    args = parser.parse_args()

   
    if not (args.wordlist and args.hash and args.type):
      
        wl = input(f"Duong dan toi wordlist [{args.wordlist or 'words.txt'}]: ").strip() or (args.wordlist or "words.txt")
        target = input(f"Hash can be [{args.hash or ''}]: ").strip() or (args.hash or "")
       
        while not target:
            target = input("Ban phai nhap hash (ví dụ: 5f4dcc3b5aa765d61d8327deb882cf99): ").strip()
        htype = input(f"Loai hash (md5/sha1) [{args.type or 'md5'}]: ").strip().lower() or (args.type or "md5")
        if htype not in ("md5", "sha1"):
            print("Loai hash khong hop le. Chon md5 hoac sha1.")
            sys.exit(1)
        wordlist_path = wl
        target_hash = target.lower()
        hash_type = htype
    else:
        wordlist_path = args.wordlist
        target_hash = args.hash.lower()
        hash_type = args.type

#    print(f"Wordlist: {wordlist_path}")
 #   print(f"Hash: {target_hash}")
  #  print(f"Loai: {hash_type}")

    crack(wordlist_path, target_hash, hash_type)

if __name__ == "__main__":
    main()
