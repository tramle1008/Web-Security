import hashlib
import itertools
import string

# Chuỗi hash MD5 cần giải mã
#  0e64a7b00c83e3d22ce6b3acf2c582b6
target_hash = input("Nhap chuoi hash: ") # hash của "password"

# Tập ký tự cần thử (chữ thường + số)
charset = string.ascii_lowercase + string.digits

# Giới hạn độ dài chuỗi cần thử
max_length =  int(input("Do dai can thu gioi han: "))

def brute_force_md5(hash_value, charset, max_len):
    for length in range(1, max_len + 1):
        print(f"Dang thu do dai: {length}")
        for candidate in itertools.product(charset, repeat=length):
            word = ''.join(candidate)
            hashed = hashlib.md5(word.encode("utf-8")).hexdigest()
            if hashed == hash_value:
                print(f" Thanh cong! Gia tri goc la: {word}")
                return
    print(" That bai! Khong tim duoc gia tri phu hop trong pham vi brute-force.")

#  Gọi hàm
brute_force_md5(target_hash, charset, max_length)
