# attacker_modify_json.py
import json
import hashlib

# read original packet (attacker can intercept)
with open("packet_vulnerable.json.bin", "rb") as f:
    message, digest = f.read().split(b"\n", 1)

print("Original message:", message.decode())
print("Original SHA1   :", digest.decode().strip())

# parse JSON, modify fields
obj = json.loads(message.decode())
# attacker changes amount and recipient
obj["amount"] = 1000000
obj["to"] = "Eve"
# produce canonical JSON bytes again
message_mod = json.dumps(obj, separators=(",", ":"), sort_keys=True).encode()

# attacker computes new sha1 (can do because sha1 is public)
digest_mod = hashlib.sha1(message_mod).hexdigest()

with open("packet_vulnerable_modified.json.bin", "wb") as f:
    f.write(message_mod + b"\n" + digest_mod.encode())

print("\nAttacker wrote packet_vulnerable_modified.json.bin")
print("Malicious message:", message_mod.decode())
print("Malicious SHA1   :", digest_mod)
