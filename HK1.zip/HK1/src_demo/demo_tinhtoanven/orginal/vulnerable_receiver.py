# vulnerable_receiver_json.py
import hashlib
from hmac import compare_digest

with open("packet_vulnerable_modified.json.bin", "rb") as f:
    content = f.read().split(b"\n", 1)

message = content[0]         # bytes (JSON)
digest_field = content[1]    # bytes (hex string)

print("Raw digest_field (bytes):", digest_field)
print("Type digest_field        :", type(digest_field))
print("Length digest_field      :", len(digest_field))

# dung decode() de chuyen tu bytes sang string ==> hash khong chua secret
digest_str = digest_field.decode().strip()
print("\nAfter decode():")
print("digest_str (type)        :", type(digest_str))
print("digest_str (value)       :", digest_str)

# compute sha1 of received message
calc_hex = hashlib.sha1(message).hexdigest()
print("\nReceiver calculated SHA1 :", calc_hex)

if compare_digest(calc_hex, digest_str):
    print("\nIntegrity OK (receiver): hashes match. (vulnerable scenario)")
else:
    print("\nIntegrity FAILED (receiver): hashes do NOT match.")
