# vulnerable_sender_json.py
import hashlib
import json

payload = {
    "type": "transfer",
    "id": "TX12345",
    "amount": 1000,
    "from": "Alice",
    "to": "Bob",
    "note": "Salary"
}
# canonical JSON bytes (ensure deterministic order)
message = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()

digest = hashlib.sha1(message).hexdigest()

with open("packet_vulnerable.json.bin", "wb") as f:
    f.write(message + b"\n" + digest.encode())

print("Wrote packet_vulnerable.json.bin")
print("Message (json):", message.decode())
print("SHA1:", digest)
