# attacker_modify_fixed.py
import json

# Attacker reads the secure packet (intercepted)
with open("packet_secure.json.bin", "rb") as f:
    content = f.read().split(b"\n", 1)

message = content[0]            # bytes (canonical json)
hmac_recv = content[1].decode().strip()  # hex string

print("Attacker sees original message:", message.decode())
print("Attacker sees original HMAC (hex):", hmac_recv)

# Attacker parses JSON to modify amount/recipient safely
obj = json.loads(message.decode())
# modify fields
obj["amount"] = 1000000
obj["to"] = "Eve"

# re-serialize deterministically (same canonical form)
message_mod = json.dumps(obj, separators=(",", ":"), sort_keys=True).encode()

# Attacker cannot compute HMAC without key, so they reuse old HMAC (forge attempt)
# (This demonstrates attacker cannot produce a valid HMAC — receiver should reject)
with open("packet_secure_modified.json.bin", "wb") as f:
    f.write(message_mod + b"\n" + hmac_recv.encode())

print("\nWrote packet_secure_modified.json.bin (attacker-modified; HMAC left unchanged)")
print("Modified message:", message_mod.decode())
print("Reused HMAC (hex):", hmac_recv)

