# fixed_sender_json.py
import os
import json
import hmac
import hashlib

# secret key (production nên lấy từ environment hoặc KMS)
secret_key = b"supersecret_shared_key"

# JSON payload giống với vulnerable_sender_json
payload = {
    "type": "transfer",
    "id": "TX12345",
    "amount": 1000,
    "from": "Alice",
    "to": "Bob",
    "note": "Salary"
}

# canonical JSON bytes (deterministic)
message = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()

# HMAC-SHA256
hmac_tag = hmac.new(secret_key, message, hashlib.sha256).hexdigest()

# ghi ra file
with open("packet_secure.json.bin", "wb") as f:
    f.write(message + b"\n" + hmac_tag.encode())

print("Wrote packet_secure.json.bin")
print("Message (json):", message.decode())
print("HMAC-SHA256 (hex):", hmac_tag)

