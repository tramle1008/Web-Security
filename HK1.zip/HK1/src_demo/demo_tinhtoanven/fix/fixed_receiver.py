# fixed_receiver.py
import hmac
import hashlib
import sys

secret_key = b"supersecret_shared_key"

# đọc file do attacker có thể đã sửa (tên file khớp với các script JSON)
fname = "packet_secure_modified.json.bin"
try:
    with open(fname, "rb") as f:
        content = f.read().split(b"\n", 1)  # chỉ split lần đầu
except FileNotFoundError:
    sys.exit(f"File not found: {fname}")

message = content[0]
hmac_recv = content[1].decode().strip() # decode() chi de dung checksum

# tính HMAC kỳ vọng trên message nhận được
h_calc = hmac.new(secret_key, message, hashlib.sha256).hexdigest()

print("Received message:", message.decode())
print("Received HMAC (hex):", hmac_recv)
print("Calculated HMAC (hex):", h_calc)

if hmac.compare_digest(h_calc, hmac_recv):
    print("Integrity OK.")
else:
    print("Integrity FAILED — possible tampering or wrong key.")

