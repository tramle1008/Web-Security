import hmac
import hashlib

# Dinh nghia cac thanh phan co ban
SECRET_KEY = b"supersecret_shared_key"
MESSAGE_ORIGINAL = b"TRANSFER:1000;FROM:Alice;TO:Bob"

def create_packet(message, key):
    # Sender: Tao goi tin an toan voi HMAC
    h = hmac.new(key, message, hashlib.sha256).hexdigest()
    print(f"   Generated HMAC: {h}")
    # Tra ve tuple (thong_diep, hmac)
    return message, h

def verify_and_process_packet(message_recv, hmac_recv, key):
    # Receiver: Xac thuc HMAC va xu ly
    h_calc = hmac.new(key, message_recv, hashlib.sha256).hexdigest()
    
    print("\n--- Receiver Verification ---")
    print(f"   Received Message: {message_recv.decode()}")
    print(f"   Received HMAC: {hmac_recv}")
    print(f"   Calculated HMAC: {h_calc}")
    
    if hmac.compare_digest(h_calc.encode(), hmac_recv.encode()):
        print("SUCCESS: Integrity OK. Processing transaction...")
        return True # Xac thuc thanh cong
    else:
        print("FAILURE: Integrity FAILED! Tampering detected.")
        print("Action: Rejecting package and requesting retransmission.")
        return False # Xac thuc that bai

# KICH BAN DEMO

# 1. TRANSMISSION 1: Goi tin goc tu Sender
print("1. SENDER: Sending original message")
packet_original = create_packet(MESSAGE_ORIGINAL, SECRET_KEY)

# 2. ATTACKER: Sua doi goi tin va gui goi gia mao
print("\n2. ATTACKER: Intercepting and modifying packet")
message_modified = MESSAGE_ORIGINAL.replace(b"1000", b"1000000")
hmac_stolen = packet_original[1] # Lay HMAC cu
packet_attack = (message_modified, hmac_stolen) 
print(f"   Attacker sends: {packet_attack[0].decode()} with original HMAC")

# 3. RECEIVER: Nhan goi gia mao va that bai (PHAT HIEN TAN CONG)
print("\n3. RECEIVER: Receiving Attacker's packet (ATTACK DETECTED)")
success = verify_and_process_packet(packet_attack[0], packet_attack[1], SECRET_KEY)

# 4. YEU CAU GUI LAI: Neu that bai, Receiver gui yeu cau va Sender gui lai
if not success:
    print("\n4. SENDER: Retransmitting original packet")
    
    # Sender gui lai Message_Goc va HMAC_Goc
    packet_retransmitted = create_packet(MESSAGE_ORIGINAL, SECRET_KEY)
    print(f"   Sender sends: {packet_retransmitted[0].decode()} with authentic HMAC")

    # 5. RECEIVER: Nhan goi tin goc va thanh cong (GIAO DICH THANH CONG)
    print("\n5. RECEIVER: Receiving Retransmitted packet (SUCCESS)")
    verify_and_process_packet(packet_retransmitted[0], packet_retransmitted[1], SECRET_KEY)
