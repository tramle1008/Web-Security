<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cổng Thông Tin Công Ty</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            background-color: #f4f4f4; 
        }
        .container { 
            display: flex; 
            max-width: 1200px; 
            margin: 20px auto; 
            background: #fff; 
            border: 1px solid #ccc;
        }
        nav { 
            width: 25%; 
            padding: 20px; 
            border-right: 1px solid #eee; 
            background: #fafafa;
        }
        nav h2 { 
            margin-top: 0; 
            color: #333; 
        }
        nav ul { 
            list-style: none; 
            padding: 0; 
        }
        nav li a { 
            text-decoration: none; 
            color: #007bff; 
            display: block; 
            padding: 8px 0; 
        }
        nav li a:hover { 
            text-decoration: underline; 
        }
        main { 
            width: 75%; 
            padding: 20px; 
        }
        .file-content {
            padding: 15px;
            border-radius: 5px;
            white-space: pre-wrap; /* Giữ nguyên định dạng và xuống dòng */
            word-wrap: break-word;
        }
    </style>
</head>
<body>
    <div class="container">
        <nav>
            <h2>Tài Liệu Chung</h2>
            <ul>
                <li><a href="?file=test.txt">Tài liệu giới thiệu (test.txt)</a></li>
                
            </ul>
        </nav>

        <main>
            <?php
                // --- PHẦN CODE CHỨA LỖ HỔNG CỦA DEMO ---

                if(isset($_GET['file'])) {
                    $file = $_GET['file']; // Lấy tham số, không lọc

                    echo "<h2>Nội dung cho: " . htmlspecialchars($file) . "</h2>";
                    
                    // Thẻ <pre> để hiển thị nội dung file (như file /etc/passwd)
                    echo "<pre class='file-content'>"; 

                    // DÒNG CODE CHỦ CHỐT GÂY RA 2 LỖ HỔNG:
                    
                    // 1. LỖI ERROR HANDLING (GĐ 1):
                    // Khi $file = "hehe.txt", nó sẽ báo lỗi và lộ đường dẫn
                    // /var/www/html/uploads/hehe.txt
                    
                    // 2. LỖI LFI (PATH TRAVERSAL):
                    // Khi $file = "../../../etc/passwd", nó sẽ đọc
                    // 'uploads/../../../etc/passwd' (tức là /etc/passwd)
                    
                    echo file_get_contents('uploads/' . $file);
                    
                    echo "</pre>";

                } else {
                    // Trang chủ mặc định khi không có tham số 'file'
                    echo "<h2>Chào mừng đến với Cổng Thông Tin!</h2>";
                    echo "<p>Vui lòng chọn một tài liệu từ menu bên trái để xem nội dung.</p>";
                }
            ?>
        </main>
    </div>
</body>
</html>
