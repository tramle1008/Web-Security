<?php
// product_page_fixed.php (FIXED - NÂNG CẤP PHÒNG THỦ CHỦ ĐỘNG)
require_once 'helpers.php';

// Cấu hình địa chỉ API nội bộ (port 8001)
$INTERNAL_API_BASE = 'http://127.0.0.1:8001/internal_api.php'; 

// --- 1. HOẠT ĐỘNG BÌNH THƯỜNG (Lấy và hiển thị sản phẩm) ---
$id = isset($_GET['id']) ? $_GET['id'] : '1';
$api_url = $INTERNAL_API_BASE . '?id=' . ($id === '1' ? '1' : '2');

$info = null;
$body = fetch_url_with_curl($api_url, $info);
$data = json_decode($body, true);

if ($info['http_code'] == 200 && $data && !isset($data['error'])) {
    echo "<h3>(Đã vá) Chi tiết sản phẩm: {$data['name']}</h3>";
    echo "<p><b>Giá:</b> " . number_format($data['price']) . " VND</p>";
    echo "<p><b>Mô tả:</b> " . htmlspecialchars($data['description']) . "</p>";
} else {
    echo "<b>(Đã vá) Không thể tải dữ liệu sản phẩm.</b>";
}
echo "<hr><pre style='font-size:11px;'>Code (Sản phẩm): {$info['http_code']}</pre>";
echo "<hr>";


// --- 2. LOGIC ĐÃ VÁ (Phòng thủ chủ động cho Referer) ---

// --- CẤU HÌNH ---
$REQUIRE_ALLOWLIST = true;
// *** BẢN SỬA LỖI ***
// Allow-list không nên chứa 'localhost' hoặc '127.0.0.1'.
// Nó chỉ nên chứa các dịch vụ bên ngoài được tin cậy, ví dụ:
$ALLOWLIST = [
    'localhost',
    '127.0.0.1',
    'some-analytics-partner.com',
    'trusted-tracker.com' 
];
// (Để trống nếu bạn không tin ai cả)

$DNS_RECHECK_DELAY = 0.2;
$LOG_DIR = __DIR__ . '/logs';
if (!is_dir($LOG_DIR)) { @mkdir($LOG_DIR, 0755, true); }
function safe_log($filename, $message) {
    global $LOG_DIR; $path = rtrim($LOG_DIR, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $filename;
    @file_put_contents($path, $message . PHP_EOL, FILE_APPEND | LOCK_EX);
}
function host_in_allowlist($host, $allowlist) {
    foreach ($allowlist as $entry) {
        $entry = trim($entry); if ($entry === '') continue;
        if (strpos($entry, '*.') === 0) {
            $suffix = substr($entry, 1);
            if (substr($host, -strlen($suffix)) === $suffix) return true;
        } else {
            if (strcasecmp($host, $entry) === 0) return true;
        }
    } return false;
}
// --- HẾT CẤU HÌNH ---

$referer_url = isset($_SERVER['HTTP_REFERER']) ? trim($_SERVER['HTTP_REFERER']) : '';

if (empty($referer_url)) {
    echo "<p>(Đã vá) Không phát hiện Referer. Bỏ qua.</p>";
    exit;
}

echo "<p>(Đã vá) Đang phân tích Referer: <code>" . htmlspecialchars($referer_url) . "</code></p>";

if (!is_valid_url($referer_url)) {
    http_response_code(400); // 400 Bad Request
    echo "<b>(Đã vá) Bị chặn (400):</b> Referer không phải là URL hợp lệ.";
    exit;
}

$parts = parse_url($referer_url);
$scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : '';
$host = isset($parts['host']) ? $parts['host'] : '';

// 1. Kiểm tra Giao thức
if (!in_array($scheme, ['http', 'https'])) {
    http_response_code(403); // 403 Forbidden
    echo "<b>(Đã vá) Bị chặn (403):</b> Giao thức '<code>" . htmlspecialchars($scheme) . "</code>' không được phép.";
    exit;
}

// 2. Kiểm tra IP Literal
if (filter_var($host, FILTER_VALIDATE_IP)) {
    if (is_private_ip($host) && !host_in_allowlist($host, $ALLOWLIST)) {
        safe_log('blocked.log', date('c') . " - BLOCKED (Ref-ip-private): $referer_url");
        http_response_code(403);
        echo "<b>(Đã vá) Bị chặn (403):</b> Referer là IP nội bộ không được phép.";
        exit;
    }
}

// 3. Kiểm tra Allow-list (Quan trọng nhất)
if ($REQUIRE_ALLOWLIST && !host_in_allowlist($host, $ALLOWLIST)) {
    safe_log('blocked.log', date('c') . " - BLOCKED (Ref-not-allowlisted): $referer_url host $host");
    http_response_code(403);
    echo "<b>(Đã vá) Bị chặn (403):</b> Host Referer '<code>" . htmlspecialchars($host) . "</code>' không có trong Allowlist.";
    exit;
}

// 4. Kiểm tra DNS
$ips1 = get_ips_for_host($host);
usleep((int)($DNS_RECHECK_DELAY * 1e6));
$ips2 = get_ips_for_host($host);
$ips_all = array_values(array_unique(array_merge($ips1, $ips2)));

if (empty($ips_all)) {
    http_response_code(403);
    echo "<b>(Đã vá) Bị chặn (403):</b> Không thể phân giải host Referer.";
    exit;
}

// 5. Kiểm tra DNS Rebinding
sort($ips1); sort($ips2);
if ($ips1 !== $ips2) {
    safe_log('blocked.log', date('c') . " - BLOCKED (Ref-dns-rebind): $referer_url");
    http_response_code(403);
    echo "<b>(Đã vá) Bị chặn (403):</b> Nghi ngờ DNS Rebinding trên Referer.";
    exit;
}

// 6. Kiểm tra IP đã phân giải (ví dụ: 'localhost' phân giải ra '127.0.0.1')
foreach ($ips_all as $ip) {
    if (is_private_ip($ip) && !host_in_allowlist($host, $ALLOWLIST)) {
        safe_log('blocked.log', date('c') . " - BLOCKED (Ref-resolved-private): $referer_url -> $ip");
        http_response_code(403);
        echo "<b>(Đã vá) Bị chặn (403):</b> Referer phân giải ra IP nội bộ.";
        exit;
    }
}

// --- Nếu tất cả kiểm tra đều qua ---
echo "<p style='color:green; font-weight:bold;'>Referer hợp lệ. Thực hiện fetch 'mù' (an toàn)...</p>";

$info_blind = null;
$body_blind = fetch_url_with_curl($referer_url, $info_blind); 
safe_log('fetch_referer.log', date('c') . " - ALLOWED (Referer): $referer_url");

echo "<p>(Đã vá) Đã fetch Referer thành công. Tác vụ hoàn tất.</p>";
?>