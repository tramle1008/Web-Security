<?php
// product_page.php (VULNERABLE - ĐÃ FIX DEADLOCK)
require_once 'helpers.php';

// Cấu hình địa chỉ API nội bộ (port 8001)
$INTERNAL_API_BASE = 'http://127.0.0.1:8001/internal_api.php'; 

// --- 1. HOẠT ĐỘNG BÌNH THƯỜNG (Lấy và hiển thị sản phẩm) ---
$id = isset($_GET['id']) ? $_GET['id'] : '1';
$api_url = $INTERNAL_API_BASE . '?id=' . ($id === '1' ? '1' : '2');

$info = null;
$body = fetch_url_with_curl($api_url, $info);
$data = json_decode($body, true);

if ($info['http_code'] == 200 && $data && !isset($data['error'])) {
    echo "<h3>(Lỗi) Chi tiết sản phẩm: {$data['name']}</h3>";
    echo "<p><b>Giá:</b> " . number_format($data['price']) . " VND</p>";
    echo "<p><b>Mô tả:</b> " . htmlspecialchars($data['description']) . "</p>";
} else {
    echo "<b>(Lỗi) Không thể tải dữ liệu sản phẩm.</b>";
}
echo "<hr><pre style='font-size:11px;'>Code (Sản phẩm): {$info['http_code']}</pre>";
echo "<hr><p>Trang này đã tải xong. Đang xử lý tác vụ nền...</p>";


// --- 2. LỖ HỔNG BLIND SSRF (Giống Lab) ---
if (isset($_SERVER['HTTP_REFERER'])) {
    $referer_url = trim($_SERVER['HTTP_REFERER']);
    
    if (is_valid_url($referer_url)) {
        
        // *** BẮT ĐẦU SỬA LỖI "CHẬM" (DEADLOCK) ***
        $parts = parse_url($referer_url);
        $host = isset($parts['host']) ? $parts['host'] : '';

        // Chỉ fetch nếu host KHÔNG PHẢI là chính nó (tránh deadlock)
        // Lỗ hổng vẫn còn vì nó sẽ fetch bất cứ host nào khác (như Oastify)
        if ($host !== '127.0.0.1' && $host !== 'localhost') {
            
            $info_blind = null;
            fetch_url_with_curl($referer_url, $info_blind);
            
            @file_put_contents(__DIR__ . '/logs/vuln_referer.log', date('c') . " - FETCHED: $referer_url" . PHP_EOL, FILE_APPEND);
        }
        // *** KẾT THÚC SỬA LỖI "CHẬM" ***
    }
}
?>