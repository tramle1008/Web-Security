<?php
// internal_api.php
// Đây là "API nội bộ" giả lập. Nó chỉ trả về JSON.
header('Content-Type: application/json');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$data = [];

switch ($id) {
    case 1:
        $data = [
            'id' => 1,
            'name' => 'Laptop XYZ',
            'price' => 25000000,
            'description' => 'Một chiếc laptop mạnh mẽ cho công việc.'
        ];
        break;
    case 2:
        $data = [
            'id' => 2,
            'name' => 'Điện thoại ABC',
            'price' => 12000000,
            'description' => 'Điện thoại thông minh với camera tuyệt vời.'
        ];
        break;
    default:
        $data = ['error' => 'Product not found'];
        http_response_code(404);
        break;
}

echo json_encode($data);
exit;
// DẤU } THỪA ĐÃ BỊ XÓA