<?php
// helpers.php (ĐÃ SỬA LỖI DNS)

function is_valid_url($url) {
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

function get_ips_for_host($host) {
    
    // --- BẮT ĐẦU SỬA LỖI ---
    // 1. FIX: Nếu host đã là một IP, trả về nó ngay lập tức.
    // Điều này tránh dùng DNS để phân giải '127.0.0.1', vốn gây ra lỗi.
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        return [$host];
    }
    // --- KẾT THÚC SỬA LỖI ---

    $ips = [];
    
    // 2. FIX: Thêm '@' để tắt (suppress) các Warning "DNS Query failed"
    // khi cố gắng phân giải các host không tồn tại (như Burp Collaborator).
    $a_records = @dns_get_record($host, DNS_A);
    if ($a_records) {
        foreach ($a_records as $r) {
            $ips[] = $r['ip'];
        }
    }
    
    $aaaa_records = @dns_get_record($host, DNS_AAAA);
    if ($aaaa_records) {
        foreach ($aaaa_records as $r) {
            $ips[] = $r['ipv6'];
        }
    }

    // Fallback cho 'localhost' (rất quan trọng)
    if (empty($ips)) {
        $ip = gethostbyname($host);
        // gethostbyname sẽ trả về chính $host nếu thất bại
        if ($ip && $ip !== $host) { 
            $ips[] = $ip;
        }
    }
    return array_unique($ips);
}

function ipv4_to_long_u($ip) {
    $long = ip2long($ip);
    if ($long === false) return false;
    return sprintf('%u', $long);
}

function is_private_ipv4($ip) {
    $l = ipv4_to_long_u($ip);
    if ($l === false) return true; // treat unknown as private (fail-safe)
    $ranges = [
        ['10.0.0.0', '10.255.255.255'],
        ['127.0.0.0', '127.255.255.255'],
        ['172.16.0.0', '172.31.255.255'],
        ['192.168.0.0', '192.168.255.255'],
        ['169.254.0.0', '169.254.255.255'],
        ['100.64.0.0', '100.127.255.255'] // shared address space
    ];
    foreach ($ranges as $r) {
        $start = ipv4_to_long_u($r[0]);
        $end = ipv4_to_long_u($r[1]);
        if ($l >= $start && $l <= $end) return true;
    }
    return false;
}

function is_private_ip($ip) {
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        return is_private_ipv4($ip);
    }
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        if ($ip === '::1') return true;
        $bin = inet_pton($ip);
        if ($bin === false) return true;
        $first = ord($bin[0]);
        if (($first & 0xfe) === 0xfc) return true; // fc00::/7
        if ($first === 0xfe) {
            $second = ord($bin[1]);
            if (($second & 0xc0) === 0x80) return true;
        }
        return false;
    }
    return true;
}

// HÀM GỐC CỦA BẠN (vẫn giữ nguyên)
function fetch_url_with_curl($url, &$info = null, $max_redirects = 1) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 1); 
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, 'ssrf-demo/1.0');
    
    $body = curl_exec($ch);
    $info = curl_getinfo($ch);
    
    $info['curl_errno'] = curl_errno($ch);
    $info['curl_error'] = curl_error($ch);
    
    curl_close($ch);
    return $body;
}