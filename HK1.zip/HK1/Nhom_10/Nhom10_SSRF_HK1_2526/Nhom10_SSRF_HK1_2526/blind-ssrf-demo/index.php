<?php
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Demo Blind SSRF (Referer)</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; max-width: 1000px; margin: 30px auto; padding: 0 16px; color:#333; background-color: #f9f9f9; }
    .card { background-color: #fff; border:1px solid #e0e0e0; border-radius:10px; padding: 20px; margin-bottom:20px; box-shadow: 0 2px 5px rgba(0,0,0,0.04); }
    h1 { margin:0 0 20px 0; font-size:26px; color: #111; text-align: center; }
    h2 { margin-top: 0; font-size: 20px; border-bottom: 2px solid #eee; padding-bottom: 8px; }
    h3 { font-size: 18px; margin: 0 0 15px 0; }
    p.note { color: #444; font-size:15px; line-height: 1.0; margin-top:0; }
    
    /* === BẮT ĐẦU SỬA LỖI BỐ CỤC === */
    .shop-layout { 
      display: grid; 
      /* Dùng grid 2 cột với tỷ lệ 1:1.2 */
      grid-template-columns: 1fr 1.2fr; 
      gap: 20px;
      /* Tự động kéo dãn 2 card cho bằng chiều cao */
      align-items: stretch; 
    }
    /* Không cần .products và .results nữa vì grid đã xử lý */
    /* === KẾT THÚC SỬA LỖI BỐ CỤC === */

    .product { border: 1px solid #ccc; border-radius: 8px; padding: 15px; margin-bottom: 15px; display: flex; align-items: center; gap: 15px; }
    .product img { width: 80px; height: 80px; object-fit: cover; border-radius: 6px; }
    .product-info { flex: 1; }
    .product-buttons { display: flex; gap: 10px; margin-top: 10px; }
    .product-buttons a { text-decoration: none; }
    #demo-frame { width: 100%; height: 350px; border: 1px solid #ccc; border-radius: 6px; background: #fdfdfd; }
    .warn { color:#b33; font-weight:600; font-size: 14px; background: #fff5f5; padding: 10px; border-radius: 5px; border-left: 3px solid #d93025; }
    
    /* Styles cho Tab */
    .tab-nav { display: flex; border-bottom: 1px solid #ddd; margin-bottom: 15px; }
    .tab-btn {
      font-size: 16px; padding: 12px 20px; border: none; background: none; cursor: pointer;
      border-bottom: 3px solid transparent; margin-bottom: -1px; font-weight: 600; color: #555;
    }
    .tab-btn:hover { background-color: #f5f5f5; }
    .tab-btn.active.vuln { color: #d93025; border-bottom-color: #d93025; }
    .tab-btn.active.fixed { color: #1a73e8; border-bottom-color: #1a73e8; }
    
    /* Chống giật khung khi chuyển tab */
    #demo-description {
       /* min-height: 100px;  */
    }
    
    /* Styles cho nút "Xem chi tiết" */
    .btn { font-size: 13px; padding: 8px 12px; border-radius:6px; border: none; color:white; cursor:pointer; font-weight: 600; text-align: center; transition: background-color 0.2s; }
    .btn:disabled { opacity: 0.7; cursor: wait; }
    .btn-vuln { background-color: #d93025; } /* Red */
    .btn-vuln:hover { background-color: #c5221b; }
    .btn-fixed { background-color: #1a73e8; } /* Blue */
    .btn-fixed:hover { background-color: #1765cc; }
  </style>
</head>
<body>

  <div class="card">
    <h1>Demo Lỗi Blind SSRF (Lỗi Referer)</h1>
    
    <div class="tab-nav">
      <button class="tab-btn" data-mode="vuln">Kịch bản Lỗi</button>
      <button class="tab-btn" data-mode="fixed">Kịch bản Đã Vá</button>
    </div>
    
    <p class="note" id="demo-description"></p>
  </div>

  <div class="shop-layout">
    <div class="products card">
      <h2>Sản phẩm</h2>
      
      <div class="product">
        <img src="./images.jpg" alt="Phone">
        <div class="product-info">
          <h3>Điện thoại ABC</h3>
          <div class="product-buttons">
            <a href="#" class="btn product-link" data-id="2" target="demo-frame">Xem chi tiết</a>
          </div>
        </div>
      </div>

      <!-- <p class="note" style="font-weight: 600; margin-top: 15px;"><b>Test Tấn công:</b> Dùng Burp Suite, bắt request, gửi qua Repeater. 
      <b>Thay đổi header <code>Referer</code></b> thành payload Collaborator của bạn.</p> -->

    </div>
    
    <div class="results card">
      <h2>Kết quả từ Server</h2>
      <iframe name="demo-frame" id="demo-frame" title="Kết quả demo"></iframe>
    </div>
  </div>

<script>
  // Mô tả cho từng kịch bản
  const vulnDesc = "<b>Kịch bản Lỗi (Vulnerable):</b> Server âm thầm đọc header <code>Referer</code> và fetch URL đó. Đây là lỗi 'mù' (blind) và chỉ có thể phát hiện bằng Burp. Bấm 'Xem chi tiết' sẽ luôn thành công (hiển thị sản phẩm), nhưng ở hậu trường request 'mù' vẫn chạy.";
  const fixedDesc = "<b>Kịch bản Đã Vá (Fixed):</b> Server vẫn đọc <code>Referer</code> nhưng áp dụng các biện pháp kiểm tra chủ động (Allow-list, IP,...). Nếu phát hiện payload (như Collaborator), nó sẽ <b>chặn (403)</b>. Nếu bạn bấm 'Xem chi tiết' ngay bây giờ, <code>Referer</code> là <code>127.0.0.1</code> (hợp lệ) và sẽ được cho qua.";

  // Lấy các phần tử
  const descElement = document.getElementById('demo-description');
  const tabButtons = document.querySelectorAll('.tab-btn');
  const productLinks = document.querySelectorAll('.product-link');
  const iframe = document.getElementById('demo-frame');
  let currentMode = 'vuln'; // Theo dõi mode hiện tại

  // Hàm CẬP NHẬT CHỈ CÁC NÚT SẢN PHẨM
  function updateProductLinks() {
    productLinks.forEach(link => {
      const id = link.getAttribute('data-id');
      if (currentMode === 'vuln') {
        link.href = `product_page.php?id=${id}`;
        link.classList.remove('btn-fixed');
        link.classList.add('btn-vuln');
        link.textContent = 'Xem chi tiết (Lỗi)';
      } else {
        link.href = `product_page_fixed.php?id=${id}`;
        link.classList.remove('btn-vuln');
        link.classList.add('btn-fixed');
        link.textContent = 'Xem chi tiết (Đã vá)';
      }
      link.disabled = false; // Luôn bật lại
    });
  }

  // Hàm CHÍNH để chuyển đổi kịch bản
  function switchDemoMode(mode) {
    currentMode = mode; // Cập nhật mode toàn cục
    
    // Cập nhật nút tab
    tabButtons.forEach(btn => {
      btn.classList.remove('active', 'vuln', 'fixed');
      if (btn.getAttribute('data-mode') === mode) {
        btn.classList.add('active', mode);
      }
    });

    // Cập nhật mô tả
    descElement.innerHTML = (mode === 'vuln') ? vulnDesc : fixedDesc;
    
    // Cập nhật các nút sản phẩm
    updateProductLinks();
  }

  // Thêm sự kiện click cho các tab
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const mode = btn.getAttribute('data-mode');
      switchDemoMode(mode);
    });
  });

  // Thêm sự kiện click cho các NÚT SẢN PHẨM (để hiện "Đang tải...")
  productLinks.forEach(link => {
    link.addEventListener('click', function() {
      // Tắt tất cả các nút
      productLinks.forEach(btn => btn.disabled = true);
      // Đặt nút này thành "Đang tải"
      this.textContent = 'Đang tải...';
    });
  });

  // Thêm sự kiện load cho IFRAME (để reset các nút)
  iframe.addEventListener('load', () => {
    // Khi iframe tải xong, cập nhật lại tất cả các nút
    // dựa trên 'currentMode' đã lưu
    updateProductLinks();
  });

  // Khởi động ở chế độ 'Lỗi' khi tải trang
  document.addEventListener('DOMContentLoaded', () => {
    switchDemoMode('vuln'); 
  });
</script>

</body>
</html>