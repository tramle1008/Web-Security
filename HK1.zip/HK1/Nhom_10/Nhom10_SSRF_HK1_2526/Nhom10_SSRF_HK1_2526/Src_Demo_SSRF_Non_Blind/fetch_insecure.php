<?php
$url = isset($_GET['url']) ? trim($_GET['url']) : '';

function h($s){return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>🧨 SSRF Demo – Bản Insecure (Chưa vá)</title>
<style>
* { box-sizing: border-box; }
body {
  font-family: "Segoe UI", system-ui, sans-serif;
  background: #f1f5f9;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.container {
  width: 95%;
  max-width: 700px;
  background: #ffffff;
  border-radius: 16px;
  margin: 40px 0;
  padding: 30px 40px;
  box-shadow: 0 8px 20px rgba(0,0,0,0.08);
  text-align: center;
}
h1 {
  color: #c60000ff;
  margin-bottom: 8px;
}
p.subtitle {
  color: #64748b;
  font-size: 0.95em;
  margin-top: 0;
  margin-bottom: 24px;
}

a.switch {
  display: inline-block;
  background: #10b981;
  color: #fff;
  padding: 10px 18px;
  border-radius: 8px;
  text-decoration: none;
  margin-top: 20px;
  font-size: 0.95em;
  transition:  0.2s;
}
a.switch:hover { background: #059669; }
.result {
  margin-top: 25px;
}
img.result-img {
  width: 100%;
  max-width: 640px;
  height: auto;
  border-radius: 14px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  margin-top: 20px;
}
pre.text-result {
  text-align: left;
  background: #f8fafc;
  padding: 16px;
  border-radius: 10px;
  font-size: 0.9em;
  line-height: 1.4em;
  color: #334155;
  overflow-x: auto;
  max-height: 400px;
  margin-top: 20px;
}
.err {
  color: #b91c1c;
  font-weight: 600;
  background: #fee2e2;
  border-radius: 8px;
  padding: 12px;
  display: inline-block;
  margin-top: 20px;
}
.note {
  color: #475569;
  margin-top: 24px;
  font-size: 0.9em;
  text-align: left;
  border-top: 1px solid #e2e8f0;
  padding-top: 10px;
}
</style>
</head>
<body>
  <div class="container">
    <h1>🧨 Demo SSRF Non-blind</h1>
    <p class="subtitle">Bản Insecure (có lỗ hỏng SSRF) – minh họa lỗi SSRF</p>
      <?php
      $ch = curl_init($url);
      curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_USERAGENT => 'SSRF-Demo-Insecure/3.0'
      ]);

      $resp = curl_exec($ch);
      if ($resp === false) {
        $err = curl_error($ch);
        echo "<p class='err'>❌ Lỗi: ".h($err)."</p>";
        curl_close($ch);
      } else {
        $ctype  = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $hsize  = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $body = substr($resp, $hsize);
        curl_close($ch);


        if ($ctype && stripos($ctype,'image/')===0) {
          // Nếu là hình ảnh thì hiển thị trực tiếp
          $base64 = base64_encode($body);
          echo "<img src='data:".h($ctype).";base64,$base64' alt='Ảnh kết quả' class='result-img'>";
        } else {
          // Nếu không phải hình ảnh thì in ra nội dung (HTML / text / JSON)
         echo "<pre class='text-result'>" . h($body) . "</pre>";
        }
      }
      ?>
      <!-- Nút trở lại trang ban đầu -->
      <div style="margin-top: 24px;">
        <a href="index.php" class="switch" style="background:#2563eb;">← Thử lại URL khác</a>
      </div>
  </div>
</body>
</html>
