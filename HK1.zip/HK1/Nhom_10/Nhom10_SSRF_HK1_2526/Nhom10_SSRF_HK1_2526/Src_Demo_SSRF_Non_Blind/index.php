<?php
// Trang chính: hiển thị form nhập URL (Insecure version mặc định)
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>SSRF Demo – URL Hình Ảnh (Insecure)</title>
<style>
body {
  font-family: system-ui, sans-serif;
  background: #f3f4f6;
  margin: 0;
  padding: 0;
}
.header {
  background: #970000ff;
  color: #fff;
  text-align: center;
  padding: 20px;
}
.header h1 {
  margin: 0;
  font-size: 1.6em;
}
.container {
  max-width: 800px;
  margin: 40px auto;
  background: #fff;
  padding: 30px;
  border-radius: 14px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
input[type="text"] {
  width: 100%;
  padding: 10px 12px;
  font-size: 1em;
  border: 1px solid #ccc;
  border-radius: 8px;
  margin-top: 8px;
}
button {
  background: #2563eb;
  color: #fff;
  border: none;
  padding: 10px 18px;
  border-radius: 8px;
  font-size: 1em;
  cursor: pointer;
  margin-top: 12px;
}
button:hover { background: #1e40af; }
a.button {
  display: inline-block;
  margin-top: 18px;
  background: #10b981;
  color: #fff;
  padding: 10px 16px;
  border-radius: 8px;
  text-decoration: none;
}
a.button:hover { background: #059669; }
.note {
  color: #666;
  margin-top: 16px;
  font-size: 0.9em;
}
.result {
  margin-top: 30px;
}
</style>
</head>
<body>
<div class="header">
  <h1>🧨 Demo SSRF Non-blind – Bản Insecure</h1>
</div>

<div class="container">
  <form method="get" action="fetch_insecure.php">
    <label>Nhập URL hình ảnh (hoặc URL bất kỳ):</label>
    <input type="text" name="url" placeholder="Nhập url hình ảnh" required>
    <button type="submit">Tải nội dung</button>
  </form>

  <a href="fetch_secure.php" class="button">🛡️ Chuyển sang bản Secure (đã vá)</a>

  <p class="note">
    💡 Bản này chưa có cơ chế bảo vệ SSRF. Bạn có thể nhập các URL nội bộ (ví dụ <code>http://localhost:9090</code>)
    để minh họa cách server gửi request thay người dùng.
  </p>
</div>
</body>
</html>
