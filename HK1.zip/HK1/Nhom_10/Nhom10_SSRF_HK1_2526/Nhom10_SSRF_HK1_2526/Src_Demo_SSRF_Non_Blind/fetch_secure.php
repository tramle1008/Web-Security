<?php
// Bản Secure: Kiểm tra scheme, allowlist, IP nội bộ, không follow redirect.
$url = isset($_GET['url']) ? trim($_GET['url']) : '';

function h($s){return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');}

$ALLOW = ['picsum.photos','images.unsplash.com']; // domain cho phép
function is_public_ip($ip){
  return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>SSRF Demo – URL Hình Ảnh (Secure)</title>
<style>
body {
  font-family: system-ui, sans-serif;
  background: #f3f4f6;
  margin: 0;
  padding: 0;
}
.header {
  background: #047857;
  color: #fff;
  text-align: center;
  padding: 20px;
}
.header h1 {
  margin: 0;
  font-size: 1.6em;
}
.container {
  max-width: 800px;
  margin: 40px auto;
  background: #fff;
  padding: 30px;
  border-radius: 14px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
input[type="text"] {
  width: 100%;
  padding: 10px 12px;
  font-size: 1em;
  border: 1px solid #ccc;
  border-radius: 8px;
  margin-top: 8px;
}
button {
  background: #047857;
  color: #fff;
  border: none;
  padding: 10px 18px;
  border-radius: 8px;
  font-size: 1em;
  cursor: pointer;
  margin-top: 12px;
}
button:hover { background: #065f46; }
a.button {
  display: inline-block;
  margin-top: 18px;
  background: #e32f2fff;
  color: #fff;
  padding: 10px 16px;
  border-radius: 8px;
  text-decoration: none;
}
a.button:hover { background: #910c0cff; }
.note {
  color: #666;
  margin-top: 16px;
  font-size: 0.9em;
}
img.result-img {
  width: 100%;
  max-width: 700px;
  border-radius: 12px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  margin-top: 20px;
}
.err {
  color: #b91c1c;
  background: #fee2e2;
  padding: 10px;
  border-radius: 8px;
  display: inline-block;
  margin-top: 20px;
  font-weight: bold;
}
pre.http {
  background: #f9fafb;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 12px;
  text-align: left;
  max-height: 300px;
  overflow: auto;
  margin-top: 20px;
  font-size: 0.9em;
}
</style>
</head>
<body>
<div class="header">
  <h1>🛡️ Demo SSRF Non-blind – Bản Secure (Đã vá lỗi)</h1>
</div>

<div class="container">
  <?php if (!$url): ?>
    <form method="get" action="">
      <label>Nhập URL hình ảnh (chỉ cho phép domain an toàn):</label>
      <input type="text" name="url" placeholder="Nhập url hình ảnh" required>
      <button type="submit">Tải nội dung</button>
    </form>

    <a href="index.php" class="button">← Quay lại bản Insecure (chưa vá)</a>

    <p class="note">
      ✅ Bản này đã có cơ chế bảo vệ SSRF:
      chỉ cho phép tải nội dung từ các domain an toàn như <code>picsum.photos</code> hoặc <code>images.unsplash.com</code>,
      không theo redirect và chặn truy cập IP nội bộ.
    </p>
  <?php else: ?>
    <?php
    $parts = @parse_url($url);
    if (!$parts || empty($parts['scheme']) || empty($parts['host'])) {
      echo "<p class='err'>❌ URL không hợp lệ.</p>";
      exit;
    }

    $scheme = strtolower($parts['scheme']);
    if (!in_array($scheme, ['http','https'], true)) {
      echo "<p class='err'>❌ Chỉ cho phép http/https.</p>";
      exit;
    }

    $host = strtolower($parts['host']);
    if (!in_array($host, $ALLOW, true)) {
      echo "<p class='err'>🚫 Host không nằm trong danh sách cho phép.</p>";
      exit;
    }

    $ips = @gethostbynamel($host);
    if (!$ips) {
      echo "<p class='err'>❌ Không resolve được host.</p>";
      exit;
    }

    foreach ($ips as $ip) {
      if (!is_public_ip($ip)) {
        echo "<p class='err'>🚫 Phát hiện IP nội bộ ($ip) → chặn truy cập.</p>";
        exit;
      }
    }

    // Nếu hợp lệ thì fetch
    $ch = curl_init($url);
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HEADER => true,
      CURLOPT_FOLLOWLOCATION => false,
      CURLOPT_TIMEOUT => 10,
      CURLOPT_CONNECTTIMEOUT => 3,
      CURLOPT_USERAGENT => 'SSRF-Demo-Secure/3.0'
    ]);

    $resp = curl_exec($ch);
    if ($resp === false) {
      echo "<p class='err'>❌ Lỗi: ".h(curl_error($ch))."</p>";
      curl_close($ch);
      exit;
    }

    $status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $ctype = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $hsize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $headers = substr($resp, 0, $hsize);
    $body = substr($resp, $hsize);
    curl_close($ch);

    // Hiển thị ảnh hoặc lỗi
    if ($ctype && stripos($ctype, 'image/') === 0) {
      $base64 = base64_encode($body);
      echo "<img src='data:".h($ctype).";base64,$base64' alt='Ảnh kết quả' class='result-img'>";
    } else {
      echo "<p class='err'>📄 Kết quả không phải hình ảnh hoặc nội dung bị chặn.</p>";
    }

    // Hiển thị phản hồi HTTP
    echo "<h3 style='margin-top:30px;text-align:left;color:#047857;'>📜 Phản hồi HTTP từ server:</h3>";
    echo "<pre class='http'>".h(trim($headers))."\n\n".h(substr($body, 0, 300)).(strlen($body) > 300 ? "\n...\n" : "")."</pre>";
    ?>
    <div style="margin-top: 24px;">
      <a href="fetch_secure.php" class="button">← Thử lại URL khác</a>
    </div>
  <?php endif; ?>
</div>
</body>
</html>
