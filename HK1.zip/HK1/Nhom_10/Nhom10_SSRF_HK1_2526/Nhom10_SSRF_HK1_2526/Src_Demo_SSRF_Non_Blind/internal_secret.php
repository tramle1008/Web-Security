<?php
header("Content-Type: text/plain; charset=utf-8");
echo "🚫 INTERNAL ONLY (demo)\n";
echo "ADMIN_USER=admin\n";
echo "ADMIN_PASS=supersecret\n";
echo "TOKEN=XYZ123ABC\n";
