#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer
import time

PORT = 9090

class SimpleHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Ghi log chi tiết request đến console
        print(f"[{time.strftime('%H:%M:%S')}] {self.address_string()} - {format % args}")

    def do_GET(self):
        print("\n=== Yêu cầu SSRF đến target server ===")
        print(f"Đường dẫn được yêu cầu: {self.path}")
        print(f"Từ IP: {self.client_address[0]}")
        print("Headers:")
        for k, v in self.headers.items():
            print(f"  {k}: {v}")
        print("======================================\n")

        # Trả lại nội dung giả lập (để thấy phản hồi trong demo PHP)
        content = f"""
        <html>
        <body style="font-family:sans-serif;">
        <h2>🎯 Target Server (localhost:{PORT})</h2>
        <p>Đây là phản hồi từ server mục tiêu (bạn đang xem kết quả SSRF non-blind).</p>
        <pre>
        Internal Info:
          SECRET_KEY = "abc123"
          ADMIN_USER = "root"
          ADMIN_PASS = "toor"
        </pre>
        <p>Request path: {self.path}</p>
        </body></html>
        """.encode("utf-8")

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

# Chạy server
if __name__ == "__main__":
    print(f"🚀 Target server chạy tại http://localhost:{PORT}")
    print("Nhấn Ctrl+C để dừng.")
    HTTPServer(("0.0.0.0", PORT), SimpleHandler).serve_forever()
